import { l as loading } from './entry-styles-3.mjs-ur4asyOn.mjs';

const aiLoadingStyles_zd9dSYp5 = [loading];

export { aiLoadingStyles_zd9dSYp5 as default };
//# sourceMappingURL=ai-loading-styles.zd9dSYp5.mjs.map
