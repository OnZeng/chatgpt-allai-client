const listList = ".list-list-box2{height:30px;line-height:30px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;width:120px}.list-list-box3{align-items:center;display:flex}";

export { listList as l };
//# sourceMappingURL=entry-styles-1.mjs-D9Gg5EBO.mjs.map
