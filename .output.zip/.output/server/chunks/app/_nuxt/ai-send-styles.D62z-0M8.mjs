const send = ".send-box1{bottom:60px;position:absolute;width:100%}.send-box1,.send-box2{display:flex;justify-content:center}.send-box2{align-items:center;gap:10px;width:60%}@media screen and (max-width:1300px){.send-box1{bottom:40px}}@media screen and (max-width:1100px){.send-box1{bottom:35px}.send-box2{width:70%}}@media screen and (max-width:900px){.send-box1{bottom:30px}}@media screen and (max-width:800px){.send-box1{bottom:25px}.send-box2{width:80%}}@media screen and (max-width:600px){.send-box1{bottom:20px}.send-box2{width:85%}}@media screen and (max-width:425px){.send-box2{width:90%}}";

const aiSendStyles_D62z0M8 = [send];

export { aiSendStyles_D62z0M8 as default };
//# sourceMappingURL=ai-send-styles.D62z-0M8.mjs.map
