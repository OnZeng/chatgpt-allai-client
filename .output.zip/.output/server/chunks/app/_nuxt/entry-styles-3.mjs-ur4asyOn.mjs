const loading = ".app-loading{align-items:center;display:flex;flex-direction:column;height:100%;justify-content:center;width:100%}.loading,.loading>div{box-sizing:border-box;position:relative}.loading{color:#18a058;display:block;font-size:0;margin:40px 0}.loading.la-dark{color:#333}.loading>div{background-color:currentColor;border:0 solid;display:inline-block;float:none}.loading{height:42px}.loading>div{animation:ball-beat .7s linear -.15s infinite;border-radius:100%;height:40px;margin:4px;width:40px}.loading>div:nth-child(2n-1){animation-delay:-.5s}@keyframes ball-beat{50%{opacity:.2;transform:scale(.75)}to{opacity:1;transform:scale(1)}}";

export { loading as l };
//# sourceMappingURL=entry-styles-3.mjs-ur4asyOn.mjs.map
