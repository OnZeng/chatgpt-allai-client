import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { f as cB, g as cM, h as c$1, l as useTheme, k as useConfig, m as formLight$1, s as cE, t as formItemInjectionKey, v as createKey, w as useThemeClass, x as resolveWrappedSlot, z as useStyle, A as useRtl, p as formatLength, B as throwError, C as keep, u as useRouter, d as useUserStore, D as useMessage, E as loginFormRef, F as rules, G as registerFormRef, j as createInjectionKey, o as keysOf, H as get_dialog_list, _ as __unplugin_components_0$3, I as __unplugin_components_1$1, J as __unplugin_components_2, K as __unplugin_components_3, e as __unplugin_components_7, q as commonVariables$m, a as useRuntimeConfig, y as warn } from '../server.mjs';
import { defineComponent, ref, provide, h, toRef, inject, watch, computed, Transition, onUnmounted, mergeProps, withCtx, createVNode, createTextVNode, unref, toDisplayString, openBlock, createBlock, createCommentVNode, useSSRContext, getCurrentInstance } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderStyle, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import { useMemo } from 'vooks';
import { createId, repeat } from 'seemly';
import Schema from 'async-validator';
import { get } from 'lodash-es';
import { _ as __unplugin_components_6 } from './Input-D2_8YhdT.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'css-render';
import '@vicons/ionicons5';
import 'evtd';
import 'treemate';
import 'vdirs';

function useInjectionInstanceCollection(injectionName, collectionKey, registerKeyRef) {
  var _a;
  const injection = inject(injectionName, null);
  if (injection === null)
    return;
  const vm = (_a = getCurrentInstance()) === null || _a === void 0 ? void 0 : _a.proxy;
  watch(registerKeyRef, registerInstance);
  registerInstance(registerKeyRef.value);
  function registerInstance(key, oldKey) {
    if (!injection)
      return;
    const collection = injection[collectionKey];
    if (oldKey !== void 0)
      removeInstance(collection, oldKey);
    if (key !== void 0)
      addInstance(collection, key);
  }
  function removeInstance(collection, key) {
    if (!collection[key])
      collection[key] = [];
    collection[key].splice(collection[key].findIndex((instance) => instance === vm), 1);
  }
  function addInstance(collection, key) {
    if (!collection[key])
      collection[key] = [];
    if (!~collection[key].findIndex((instance) => instance === vm)) {
      collection[key].push(vm);
    }
  }
}
const style$2 = cB("form", [cM("inline", `
 width: 100%;
 display: inline-flex;
 align-items: flex-start;
 align-content: space-around;
 `, [cB("form-item", {
  width: "auto",
  marginRight: "18px"
}, [c$1("&:last-child", {
  marginRight: 0
})])])]);
const formInjectionKey = createInjectionKey("n-form");
const formItemInstsInjectionKey = createInjectionKey("n-form-item-insts");
var __awaiter$1 = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
const formProps = Object.assign(Object.assign({}, useTheme.props), {
  inline: Boolean,
  labelWidth: [Number, String],
  labelAlign: String,
  labelPlacement: {
    type: String,
    default: "top"
  },
  model: {
    type: Object,
    default: () => {
    }
  },
  rules: Object,
  disabled: Boolean,
  size: String,
  showRequireMark: {
    type: Boolean,
    default: void 0
  },
  requireMarkPlacement: String,
  showFeedback: {
    type: Boolean,
    default: true
  },
  onSubmit: {
    type: Function,
    default: (e) => {
      e.preventDefault();
    }
  },
  showLabel: {
    type: Boolean,
    default: void 0
  },
  validateMessages: Object
});
const __unplugin_components_4 = defineComponent({
  name: "Form",
  props: formProps,
  setup(props) {
    const {
      mergedClsPrefixRef
    } = useConfig(props);
    useTheme("Form", "-form", style$2, formLight$1, props, mergedClsPrefixRef);
    const formItems = {};
    const maxChildLabelWidthRef = ref(void 0);
    const deriveMaxChildLabelWidth = (currentWidth) => {
      const currentMaxChildLabelWidth = maxChildLabelWidthRef.value;
      if (currentMaxChildLabelWidth === void 0 || currentWidth >= currentMaxChildLabelWidth) {
        maxChildLabelWidthRef.value = currentWidth;
      }
    };
    function validate(validateCallback, shouldRuleBeApplied = () => true) {
      return __awaiter$1(this, void 0, void 0, function* () {
        return yield new Promise((resolve, reject) => {
          const formItemValidationPromises = [];
          for (const key of keysOf(formItems)) {
            const formItemInstances = formItems[key];
            for (const formItemInstance of formItemInstances) {
              if (formItemInstance.path) {
                formItemValidationPromises.push(formItemInstance.internalValidate(null, shouldRuleBeApplied));
              }
            }
          }
          void Promise.all(formItemValidationPromises).then((results) => {
            const formInvalid = results.some((result) => !result.valid);
            const errors = [];
            const warnings = [];
            results.forEach((result) => {
              var _a, _b;
              if ((_a = result.errors) === null || _a === void 0 ? void 0 : _a.length) {
                errors.push(result.errors);
              }
              if ((_b = result.warnings) === null || _b === void 0 ? void 0 : _b.length) {
                warnings.push(result.warnings);
              }
            });
            if (validateCallback) {
              validateCallback(errors.length ? errors : void 0, {
                warnings: warnings.length ? warnings : void 0
              });
            }
            if (formInvalid) {
              reject(errors.length ? errors : void 0);
            } else {
              resolve({
                warnings: warnings.length ? warnings : void 0
              });
            }
          });
        });
      });
    }
    function restoreValidation() {
      for (const key of keysOf(formItems)) {
        const formItemInstances = formItems[key];
        for (const formItemInstance of formItemInstances) {
          formItemInstance.restoreValidation();
        }
      }
    }
    provide(formInjectionKey, {
      props,
      maxChildLabelWidthRef,
      deriveMaxChildLabelWidth
    });
    provide(formItemInstsInjectionKey, {
      formItems
    });
    const formExposedMethod = {
      validate,
      restoreValidation
    };
    return Object.assign(formExposedMethod, {
      mergedClsPrefix: mergedClsPrefixRef
    });
  },
  render() {
    const {
      mergedClsPrefix
    } = this;
    return h("form", {
      class: [`${mergedClsPrefix}-form`, this.inline && `${mergedClsPrefix}-form--inline`],
      onSubmit: this.onSubmit
    }, this.$slots);
  }
});
function formItemSize(props) {
  const NForm = inject(formInjectionKey, null);
  return {
    mergedSize: computed(() => {
      if (props.size !== void 0)
        return props.size;
      if ((NForm === null || NForm === void 0 ? void 0 : NForm.props.size) !== void 0)
        return NForm.props.size;
      return "medium";
    })
  };
}
function formItemMisc(props) {
  const NForm = inject(formInjectionKey, null);
  const mergedLabelPlacementRef = computed(() => {
    const {
      labelPlacement
    } = props;
    if (labelPlacement !== void 0)
      return labelPlacement;
    if (NForm === null || NForm === void 0 ? void 0 : NForm.props.labelPlacement)
      return NForm.props.labelPlacement;
    return "top";
  });
  const isAutoLabelWidthRef = computed(() => {
    return mergedLabelPlacementRef.value === "left" && (props.labelWidth === "auto" || (NForm === null || NForm === void 0 ? void 0 : NForm.props.labelWidth) === "auto");
  });
  const mergedLabelWidthRef = computed(() => {
    if (mergedLabelPlacementRef.value === "top")
      return;
    const {
      labelWidth
    } = props;
    if (labelWidth !== void 0 && labelWidth !== "auto") {
      return formatLength(labelWidth);
    }
    if (isAutoLabelWidthRef.value) {
      const autoComputedWidth = NForm === null || NForm === void 0 ? void 0 : NForm.maxChildLabelWidthRef.value;
      if (autoComputedWidth !== void 0) {
        return formatLength(autoComputedWidth);
      } else {
        return void 0;
      }
    }
    if ((NForm === null || NForm === void 0 ? void 0 : NForm.props.labelWidth) !== void 0) {
      return formatLength(NForm.props.labelWidth);
    }
    return void 0;
  });
  const mergedLabelAlignRef = computed(() => {
    const {
      labelAlign
    } = props;
    if (labelAlign)
      return labelAlign;
    if (NForm === null || NForm === void 0 ? void 0 : NForm.props.labelAlign)
      return NForm.props.labelAlign;
    return void 0;
  });
  const mergedLabelStyleRef = computed(() => {
    var _a;
    return [(_a = props.labelProps) === null || _a === void 0 ? void 0 : _a.style, props.labelStyle, {
      width: mergedLabelWidthRef.value
    }];
  });
  const mergedShowRequireMarkRef = computed(() => {
    const {
      showRequireMark
    } = props;
    if (showRequireMark !== void 0)
      return showRequireMark;
    return NForm === null || NForm === void 0 ? void 0 : NForm.props.showRequireMark;
  });
  const mergedRequireMarkPlacementRef = computed(() => {
    const {
      requireMarkPlacement
    } = props;
    if (requireMarkPlacement !== void 0)
      return requireMarkPlacement;
    return (NForm === null || NForm === void 0 ? void 0 : NForm.props.requireMarkPlacement) || "right";
  });
  const validationErroredRef = ref(false);
  const validationWarnedRef = ref(false);
  const mergedValidationStatusRef = computed(() => {
    const {
      validationStatus
    } = props;
    if (validationStatus !== void 0)
      return validationStatus;
    if (validationErroredRef.value)
      return "error";
    if (validationWarnedRef.value)
      return "warning";
    return void 0;
  });
  const mergedShowFeedbackRef = computed(() => {
    const {
      showFeedback
    } = props;
    if (showFeedback !== void 0)
      return showFeedback;
    if ((NForm === null || NForm === void 0 ? void 0 : NForm.props.showFeedback) !== void 0)
      return NForm.props.showFeedback;
    return true;
  });
  const mergedShowLabelRef = computed(() => {
    const {
      showLabel
    } = props;
    if (showLabel !== void 0)
      return showLabel;
    if ((NForm === null || NForm === void 0 ? void 0 : NForm.props.showLabel) !== void 0)
      return NForm.props.showLabel;
    return true;
  });
  return {
    validationErrored: validationErroredRef,
    validationWarned: validationWarnedRef,
    mergedLabelStyle: mergedLabelStyleRef,
    mergedLabelPlacement: mergedLabelPlacementRef,
    mergedLabelAlign: mergedLabelAlignRef,
    mergedShowRequireMark: mergedShowRequireMarkRef,
    mergedRequireMarkPlacement: mergedRequireMarkPlacementRef,
    mergedValidationStatus: mergedValidationStatusRef,
    mergedShowFeedback: mergedShowFeedbackRef,
    mergedShowLabel: mergedShowLabelRef,
    isAutoLabelWidth: isAutoLabelWidthRef
  };
}
function formItemRule(props) {
  const NForm = inject(formInjectionKey, null);
  const compatibleRulePathRef = computed(() => {
    const {
      rulePath
    } = props;
    if (rulePath !== void 0)
      return rulePath;
    const {
      path
    } = props;
    if (path !== void 0)
      return path;
    return void 0;
  });
  const mergedRulesRef = computed(() => {
    const rules2 = [];
    const {
      rule
    } = props;
    if (rule !== void 0) {
      if (Array.isArray(rule))
        rules2.push(...rule);
      else
        rules2.push(rule);
    }
    if (NForm) {
      const {
        rules: formRules
      } = NForm.props;
      const {
        value: rulePath
      } = compatibleRulePathRef;
      if (formRules !== void 0 && rulePath !== void 0) {
        const formRule = get(formRules, rulePath);
        if (formRule !== void 0) {
          if (Array.isArray(formRule)) {
            rules2.push(...formRule);
          } else {
            rules2.push(formRule);
          }
        }
      }
    }
    return rules2;
  });
  const hasRequiredRuleRef = computed(() => {
    return mergedRulesRef.value.some((rule) => rule.required);
  });
  const mergedRequiredRef = computed(() => {
    return hasRequiredRuleRef.value || props.required;
  });
  return {
    mergedRules: mergedRulesRef,
    mergedRequired: mergedRequiredRef
  };
}
const {
  cubicBezierEaseInOut
} = commonVariables$m;
function fadeDownTransition({
  name = "fade-down",
  fromOffset = "-4px",
  enterDuration = ".3s",
  leaveDuration = ".3s",
  enterCubicBezier = cubicBezierEaseInOut,
  leaveCubicBezier = cubicBezierEaseInOut
} = {}) {
  return [c$1(`&.${name}-transition-enter-from, &.${name}-transition-leave-to`, {
    opacity: 0,
    transform: `translateY(${fromOffset})`
  }), c$1(`&.${name}-transition-enter-to, &.${name}-transition-leave-from`, {
    opacity: 1,
    transform: "translateY(0)"
  }), c$1(`&.${name}-transition-leave-active`, {
    transition: `opacity ${leaveDuration} ${leaveCubicBezier}, transform ${leaveDuration} ${leaveCubicBezier}`
  }), c$1(`&.${name}-transition-enter-active`, {
    transition: `opacity ${enterDuration} ${enterCubicBezier}, transform ${enterDuration} ${enterCubicBezier}`
  })];
}
const style$1 = cB("form-item", `
 display: grid;
 line-height: var(--n-line-height);
`, [cB("form-item-label", `
 grid-area: label;
 align-items: center;
 line-height: 1.25;
 text-align: var(--n-label-text-align);
 font-size: var(--n-label-font-size);
 min-height: var(--n-label-height);
 padding: var(--n-label-padding);
 color: var(--n-label-text-color);
 transition: color .3s var(--n-bezier);
 box-sizing: border-box;
 font-weight: var(--n-label-font-weight);
 `, [cE("asterisk", `
 white-space: nowrap;
 user-select: none;
 -webkit-user-select: none;
 color: var(--n-asterisk-color);
 transition: color .3s var(--n-bezier);
 `), cE("asterisk-placeholder", `
 grid-area: mark;
 user-select: none;
 -webkit-user-select: none;
 visibility: hidden; 
 `)]), cB("form-item-blank", `
 grid-area: blank;
 min-height: var(--n-blank-height);
 `), cM("auto-label-width", [cB("form-item-label", "white-space: nowrap;")]), cM("left-labelled", `
 grid-template-areas:
 "label blank"
 "label feedback";
 grid-template-columns: auto minmax(0, 1fr);
 grid-template-rows: auto 1fr;
 align-items: flex-start;
 `, [cB("form-item-label", `
 display: grid;
 grid-template-columns: 1fr auto;
 min-height: var(--n-blank-height);
 height: auto;
 box-sizing: border-box;
 flex-shrink: 0;
 flex-grow: 0;
 `, [cM("reverse-columns-space", `
 grid-template-columns: auto 1fr;
 `), cM("left-mark", `
 grid-template-areas:
 "mark text"
 ". text";
 `), cM("right-mark", `
 grid-template-areas: 
 "text mark"
 "text .";
 `), cM("right-hanging-mark", `
 grid-template-areas: 
 "text mark"
 "text .";
 `), cE("text", `
 grid-area: text; 
 `), cE("asterisk", `
 grid-area: mark; 
 align-self: end;
 `)])]), cM("top-labelled", `
 grid-template-areas:
 "label"
 "blank"
 "feedback";
 grid-template-rows: minmax(var(--n-label-height), auto) 1fr;
 grid-template-columns: minmax(0, 100%);
 `, [cM("no-label", `
 grid-template-areas:
 "blank"
 "feedback";
 grid-template-rows: 1fr;
 `), cB("form-item-label", `
 display: flex;
 align-items: flex-start;
 justify-content: var(--n-label-text-align);
 `)]), cB("form-item-blank", `
 box-sizing: border-box;
 display: flex;
 align-items: center;
 position: relative;
 `), cB("form-item-feedback-wrapper", `
 grid-area: feedback;
 box-sizing: border-box;
 min-height: var(--n-feedback-height);
 font-size: var(--n-feedback-font-size);
 line-height: 1.25;
 transform-origin: top left;
 `, [c$1("&:not(:empty)", `
 padding: var(--n-feedback-padding);
 `), cB("form-item-feedback", {
  transition: "color .3s var(--n-bezier)",
  color: "var(--n-feedback-text-color)"
}, [cM("warning", {
  color: "var(--n-feedback-text-color-warning)"
}), cM("error", {
  color: "var(--n-feedback-text-color-error)"
}), fadeDownTransition({
  fromOffset: "-3px",
  enterDuration: ".3s",
  leaveDuration: ".2s"
})])])]);
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
const formItemProps = Object.assign(Object.assign({}, useTheme.props), {
  label: String,
  labelWidth: [Number, String],
  labelStyle: [String, Object],
  labelAlign: String,
  labelPlacement: String,
  path: String,
  first: Boolean,
  rulePath: String,
  required: Boolean,
  showRequireMark: {
    type: Boolean,
    default: void 0
  },
  requireMarkPlacement: String,
  showFeedback: {
    type: Boolean,
    default: void 0
  },
  rule: [Object, Array],
  size: String,
  ignorePathChange: Boolean,
  validationStatus: String,
  feedback: String,
  showLabel: {
    type: Boolean,
    default: void 0
  },
  labelProps: Object
});
const formItemPropKeys = keysOf(formItemProps);
function wrapValidator(validator, async) {
  return (...args) => {
    try {
      const validateResult = validator(...args);
      if (!async && (typeof validateResult === "boolean" || validateResult instanceof Error || Array.isArray(validateResult)) || // Error[]
      (validateResult === null || validateResult === void 0 ? void 0 : validateResult.then)) {
        return validateResult;
      } else if (validateResult === void 0) {
        return true;
      } else {
        warn("form-item/validate", `You return a ${typeof validateResult} typed value in the validator method, which is not recommended. Please use ` + (async ? "`Promise`" : "`boolean`, `Error` or `Promise`") + " typed value instead.");
        return true;
      }
    } catch (err) {
      warn("form-item/validate", "An error is catched in the validation, so the validation won't be done. Your callback in `validate` method of `n-form` or `n-form-item` won't be called in this validation.");
      console.error(err);
      return void 0;
    }
  };
}
const NFormItem = defineComponent({
  name: "FormItem",
  props: formItemProps,
  setup(props) {
    useInjectionInstanceCollection(formItemInstsInjectionKey, "formItems", toRef(props, "path"));
    const {
      mergedClsPrefixRef,
      inlineThemeDisabled
    } = useConfig(props);
    const NForm = inject(formInjectionKey, null);
    const formItemSizeRefs = formItemSize(props);
    const formItemMiscRefs = formItemMisc(props);
    const {
      validationErrored: validationErroredRef,
      validationWarned: validationWarnedRef
    } = formItemMiscRefs;
    const {
      mergedRequired: mergedRequiredRef,
      mergedRules: mergedRulesRef
    } = formItemRule(props);
    const {
      mergedSize: mergedSizeRef
    } = formItemSizeRefs;
    const {
      mergedLabelPlacement: labelPlacementRef,
      mergedLabelAlign: labelTextAlignRef,
      mergedRequireMarkPlacement: mergedRequireMarkPlacementRef
    } = formItemMiscRefs;
    const renderExplainsRef = ref([]);
    const feedbackIdRef = ref(createId());
    const mergedDisabledRef = NForm ? toRef(NForm.props, "disabled") : ref(false);
    const themeRef = useTheme("Form", "-form-item", style$1, formLight$1, props, mergedClsPrefixRef);
    watch(toRef(props, "path"), () => {
      if (props.ignorePathChange)
        return;
      restoreValidation();
    });
    function restoreValidation() {
      renderExplainsRef.value = [];
      validationErroredRef.value = false;
      validationWarnedRef.value = false;
      if (props.feedback) {
        feedbackIdRef.value = createId();
      }
    }
    function handleContentBlur() {
      void internalValidate("blur");
    }
    function handleContentChange() {
      void internalValidate("change");
    }
    function handleContentFocus() {
      void internalValidate("focus");
    }
    function handleContentInput() {
      void internalValidate("input");
    }
    function validate(options, callback) {
      return __awaiter(this, void 0, void 0, function* () {
        let trigger;
        let validateCallback;
        let shouldRuleBeApplied;
        let asyncValidatorOptions;
        if (typeof options === "string") {
          trigger = options;
          validateCallback = callback;
        } else if (options !== null && typeof options === "object") {
          trigger = options.trigger;
          validateCallback = options.callback;
          shouldRuleBeApplied = options.shouldRuleBeApplied;
          asyncValidatorOptions = options.options;
        }
        return yield new Promise((resolve, reject) => {
          void internalValidate(trigger, shouldRuleBeApplied, asyncValidatorOptions).then(({
            valid,
            errors,
            warnings
          }) => {
            if (valid) {
              if (validateCallback) {
                validateCallback(void 0, {
                  warnings
                });
              }
              resolve({
                warnings
              });
            } else {
              if (validateCallback) {
                validateCallback(errors, {
                  warnings
                });
              }
              reject(errors);
            }
          });
        });
      });
    }
    const internalValidate = (trigger = null, shouldRuleBeApplied = () => true, options = {
      suppressWarning: true
    }) => __awaiter(this, void 0, void 0, function* () {
      const {
        path
      } = props;
      if (!options) {
        options = {};
      } else {
        if (!options.first)
          options.first = props.first;
      }
      const {
        value: rules2
      } = mergedRulesRef;
      const value = NForm ? get(NForm.props.model, path || "") : void 0;
      const messageRenderers = {};
      const originalMessageRendersMessage = {};
      const activeRules = (!trigger ? rules2 : rules2.filter((rule) => {
        if (Array.isArray(rule.trigger)) {
          return rule.trigger.includes(trigger);
        } else {
          return rule.trigger === trigger;
        }
      })).filter(shouldRuleBeApplied).map((rule, i) => {
        const shallowClonedRule = Object.assign({}, rule);
        if (shallowClonedRule.validator) {
          shallowClonedRule.validator = wrapValidator(shallowClonedRule.validator, false);
        }
        if (shallowClonedRule.asyncValidator) {
          shallowClonedRule.asyncValidator = wrapValidator(shallowClonedRule.asyncValidator, true);
        }
        if (shallowClonedRule.renderMessage) {
          const rendererKey = `__renderMessage__${i}`;
          originalMessageRendersMessage[rendererKey] = shallowClonedRule.message;
          shallowClonedRule.message = rendererKey;
          messageRenderers[rendererKey] = shallowClonedRule.renderMessage;
        }
        return shallowClonedRule;
      });
      const activeErrorRules = activeRules.filter((r) => r.level !== "warning");
      const activeWarningRules = activeRules.filter((r) => r.level === "warning");
      const mergedPath = path !== null && path !== void 0 ? path : "__n_no_path__";
      const validator = new Schema({
        [mergedPath]: activeErrorRules
      });
      const warningValidator = new Schema({
        [mergedPath]: activeWarningRules
      });
      const {
        validateMessages
      } = (NForm === null || NForm === void 0 ? void 0 : NForm.props) || {};
      if (validateMessages) {
        validator.messages(validateMessages);
        warningValidator.messages(validateMessages);
      }
      const renderMessages = (errors) => {
        renderExplainsRef.value = errors.map((error) => {
          const transformedMessage = (error === null || error === void 0 ? void 0 : error.message) || "";
          return {
            key: transformedMessage,
            render: () => {
              if (transformedMessage.startsWith("__renderMessage__")) {
                return messageRenderers[transformedMessage]();
              }
              return transformedMessage;
            }
          };
        });
        errors.forEach((error) => {
          var _a;
          if ((_a = error.message) === null || _a === void 0 ? void 0 : _a.startsWith("__renderMessage__")) {
            error.message = originalMessageRendersMessage[error.message];
          }
        });
      };
      const validationResult = {
        valid: true,
        errors: void 0,
        warnings: void 0
      };
      if (activeErrorRules.length) {
        const errors = yield new Promise((resolve) => {
          void validator.validate({
            [mergedPath]: value
          }, options, resolve);
        });
        if (errors === null || errors === void 0 ? void 0 : errors.length) {
          validationErroredRef.value = true;
          validationResult.valid = false;
          validationResult.errors = errors;
          renderMessages(errors);
        }
      }
      if (activeWarningRules.length && !validationResult.errors) {
        const warnings = yield new Promise((resolve) => {
          void warningValidator.validate({
            [mergedPath]: value
          }, options, resolve);
        });
        if (warnings === null || warnings === void 0 ? void 0 : warnings.length) {
          renderMessages(warnings);
          validationWarnedRef.value = true;
          validationResult.warnings = warnings;
        }
      }
      if (activeErrorRules.length + activeWarningRules.length > 0 && !validationResult.errors && !validationResult.warnings) {
        restoreValidation();
      }
      return validationResult;
    });
    provide(formItemInjectionKey, {
      path: toRef(props, "path"),
      disabled: mergedDisabledRef,
      mergedSize: formItemSizeRefs.mergedSize,
      mergedValidationStatus: formItemMiscRefs.mergedValidationStatus,
      restoreValidation,
      handleContentBlur,
      handleContentChange,
      handleContentFocus,
      handleContentInput
    });
    const exposedRef = {
      validate,
      restoreValidation,
      internalValidate
    };
    const labelElementRef = ref(null);
    const cssVarsRef = computed(() => {
      var _a;
      const {
        value: size
      } = mergedSizeRef;
      const {
        value: labelPlacement
      } = labelPlacementRef;
      const direction = labelPlacement === "top" ? "vertical" : "horizontal";
      const {
        common: {
          cubicBezierEaseInOut: cubicBezierEaseInOut2
        },
        self: {
          labelTextColor,
          asteriskColor,
          lineHeight,
          feedbackTextColor,
          feedbackTextColorWarning,
          feedbackTextColorError,
          feedbackPadding,
          labelFontWeight,
          [createKey("labelHeight", size)]: labelHeight,
          [createKey("blankHeight", size)]: blankHeight,
          [createKey("feedbackFontSize", size)]: feedbackFontSize,
          [createKey("feedbackHeight", size)]: feedbackHeight,
          [createKey("labelPadding", direction)]: labelPadding,
          [createKey("labelTextAlign", direction)]: labelTextAlign,
          [createKey(createKey("labelFontSize", labelPlacement), size)]: labelFontSize
        }
      } = themeRef.value;
      let mergedLabelTextAlign = (_a = labelTextAlignRef.value) !== null && _a !== void 0 ? _a : labelTextAlign;
      if (labelPlacement === "top") {
        mergedLabelTextAlign = mergedLabelTextAlign === "right" ? "flex-end" : "flex-start";
      }
      const cssVars = {
        "--n-bezier": cubicBezierEaseInOut2,
        "--n-line-height": lineHeight,
        "--n-blank-height": blankHeight,
        "--n-label-font-size": labelFontSize,
        "--n-label-text-align": mergedLabelTextAlign,
        "--n-label-height": labelHeight,
        "--n-label-padding": labelPadding,
        "--n-label-font-weight": labelFontWeight,
        "--n-asterisk-color": asteriskColor,
        "--n-label-text-color": labelTextColor,
        "--n-feedback-padding": feedbackPadding,
        "--n-feedback-font-size": feedbackFontSize,
        "--n-feedback-height": feedbackHeight,
        "--n-feedback-text-color": feedbackTextColor,
        "--n-feedback-text-color-warning": feedbackTextColorWarning,
        "--n-feedback-text-color-error": feedbackTextColorError
      };
      return cssVars;
    });
    const themeClassHandle = inlineThemeDisabled ? useThemeClass("form-item", computed(() => {
      var _a;
      return `${mergedSizeRef.value[0]}${labelPlacementRef.value[0]}${((_a = labelTextAlignRef.value) === null || _a === void 0 ? void 0 : _a[0]) || ""}`;
    }), cssVarsRef, props) : void 0;
    const reverseColSpaceRef = computed(() => {
      return labelPlacementRef.value === "left" && mergedRequireMarkPlacementRef.value === "left" && labelTextAlignRef.value === "left";
    });
    return Object.assign(Object.assign(Object.assign(Object.assign({
      labelElementRef,
      mergedClsPrefix: mergedClsPrefixRef,
      mergedRequired: mergedRequiredRef,
      feedbackId: feedbackIdRef,
      renderExplains: renderExplainsRef,
      reverseColSpace: reverseColSpaceRef
    }, formItemMiscRefs), formItemSizeRefs), exposedRef), {
      cssVars: inlineThemeDisabled ? void 0 : cssVarsRef,
      themeClass: themeClassHandle === null || themeClassHandle === void 0 ? void 0 : themeClassHandle.themeClass,
      onRender: themeClassHandle === null || themeClassHandle === void 0 ? void 0 : themeClassHandle.onRender
    });
  },
  render() {
    const {
      $slots,
      mergedClsPrefix,
      mergedShowLabel,
      mergedShowRequireMark,
      mergedRequireMarkPlacement,
      onRender
    } = this;
    const renderedShowRequireMark = mergedShowRequireMark !== void 0 ? mergedShowRequireMark : this.mergedRequired;
    onRender === null || onRender === void 0 ? void 0 : onRender();
    const renderLabel = () => {
      const labelText = this.$slots.label ? this.$slots.label() : this.label;
      if (!labelText)
        return null;
      const textNode = h("span", {
        class: `${mergedClsPrefix}-form-item-label__text`
      }, labelText);
      const markNode = renderedShowRequireMark ? h("span", {
        class: `${mergedClsPrefix}-form-item-label__asterisk`
      }, mergedRequireMarkPlacement !== "left" ? "\xA0*" : "*\xA0") : mergedRequireMarkPlacement === "right-hanging" && h("span", {
        class: `${mergedClsPrefix}-form-item-label__asterisk-placeholder`
      }, "\xA0*");
      const {
        labelProps
      } = this;
      return h("label", Object.assign({}, labelProps, {
        class: [labelProps === null || labelProps === void 0 ? void 0 : labelProps.class, `${mergedClsPrefix}-form-item-label`, `${mergedClsPrefix}-form-item-label--${mergedRequireMarkPlacement}-mark`, this.reverseColSpace && `${mergedClsPrefix}-form-item-label--reverse-columns-space`],
        style: this.mergedLabelStyle,
        ref: "labelElementRef"
      }), mergedRequireMarkPlacement === "left" ? [markNode, textNode] : [textNode, markNode]);
    };
    return h("div", {
      class: [`${mergedClsPrefix}-form-item`, this.themeClass, `${mergedClsPrefix}-form-item--${this.mergedSize}-size`, `${mergedClsPrefix}-form-item--${this.mergedLabelPlacement}-labelled`, this.isAutoLabelWidth && `${mergedClsPrefix}-form-item--auto-label-width`, !mergedShowLabel && `${mergedClsPrefix}-form-item--no-label`],
      style: this.cssVars
    }, mergedShowLabel && renderLabel(), h("div", {
      class: [`${mergedClsPrefix}-form-item-blank`, this.mergedValidationStatus && `${mergedClsPrefix}-form-item-blank--${this.mergedValidationStatus}`]
    }, $slots), this.mergedShowFeedback ? h("div", {
      key: this.feedbackId,
      class: `${mergedClsPrefix}-form-item-feedback-wrapper`
    }, h(Transition, {
      name: "fade-down-transition",
      mode: "out-in"
    }, {
      default: () => {
        const {
          mergedValidationStatus
        } = this;
        return resolveWrappedSlot($slots.feedback, (children) => {
          var _a;
          const {
            feedback
          } = this;
          const feedbackNodes = children || feedback ? h("div", {
            key: "__feedback__",
            class: `${mergedClsPrefix}-form-item-feedback__line`
          }, children || feedback) : this.renderExplains.length ? (_a = this.renderExplains) === null || _a === void 0 ? void 0 : _a.map(({
            key,
            render
          }) => h("div", {
            key,
            class: `${mergedClsPrefix}-form-item-feedback__line`
          }, render())) : null;
          return feedbackNodes ? mergedValidationStatus === "warning" ? h("div", {
            key: "controlled-warning",
            class: `${mergedClsPrefix}-form-item-feedback ${mergedClsPrefix}-form-item-feedback--warning`
          }, feedbackNodes) : mergedValidationStatus === "error" ? h("div", {
            key: "controlled-error",
            class: `${mergedClsPrefix}-form-item-feedback ${mergedClsPrefix}-form-item-feedback--error`
          }, feedbackNodes) : mergedValidationStatus === "success" ? h("div", {
            key: "controlled-success",
            class: `${mergedClsPrefix}-form-item-feedback ${mergedClsPrefix}-form-item-feedback--success`
          }, feedbackNodes) : h("div", {
            key: "controlled-default",
            class: `${mergedClsPrefix}-form-item-feedback`
          }, feedbackNodes) : null;
        });
      }
    })) : null);
  }
});
const positionStyles = repeat(24, null).map((_, index) => {
  const prefixIndex = index + 1;
  const percent = `calc(100% / 24 * ${prefixIndex})`;
  return [cM(`${prefixIndex}-span`, {
    width: percent
  }), cM(`${prefixIndex}-offset`, {
    marginLeft: percent
  }), cM(`${prefixIndex}-push`, {
    left: percent
  }), cM(`${prefixIndex}-pull`, {
    right: percent
  })];
});
const style = c$1([cB("row", {
  width: "100%",
  display: "flex",
  flexWrap: "wrap"
}), cB("col", {
  verticalAlign: "top",
  boxSizing: "border-box",
  display: "inline-block",
  position: "relative",
  zIndex: "auto"
}, [cE("box", {
  position: "relative",
  zIndex: "auto",
  width: "100%",
  height: "100%"
}), positionStyles])]);
const rowInjectionKey = createInjectionKey("n-row");
const rowProps = {
  gutter: {
    type: [Array, Number, String],
    default: 0
  },
  alignItems: String,
  justifyContent: String
};
const rowPropKeys = keysOf(rowProps);
const NRow = defineComponent({
  name: "Row",
  props: rowProps,
  setup(props) {
    const {
      mergedClsPrefixRef,
      mergedRtlRef
    } = useConfig(props);
    useStyle("-legacy-grid", style, mergedClsPrefixRef);
    const rtlEnabledRef = useRtl("Row", mergedRtlRef, mergedClsPrefixRef);
    const verticalGutterRef = useMemo(() => {
      const {
        gutter
      } = props;
      if (Array.isArray(gutter)) {
        return gutter[1] || 0;
      }
      return 0;
    });
    const horizontalGutterRef = useMemo(() => {
      const {
        gutter
      } = props;
      if (Array.isArray(gutter)) {
        return gutter[0];
      }
      return Number(gutter);
    });
    provide(rowInjectionKey, {
      mergedClsPrefixRef,
      gutterRef: toRef(props, "gutter"),
      verticalGutterRef,
      horizontalGutterRef
    });
    return {
      mergedClsPrefix: mergedClsPrefixRef,
      rtlEnabled: rtlEnabledRef,
      styleMargin: useMemo(() => `-${formatLength(verticalGutterRef.value, {
        c: 0.5
      })} -${formatLength(horizontalGutterRef.value, {
        c: 0.5
      })}`),
      styleWidth: useMemo(() => `calc(100% + ${formatLength(horizontalGutterRef.value)})`)
    };
  },
  render() {
    return h("div", {
      class: [`${this.mergedClsPrefix}-row`, this.rtlEnabled && `${this.mergedClsPrefix}-row--rtl`],
      style: {
        margin: this.styleMargin,
        width: this.styleWidth,
        alignItems: this.alignItems,
        justifyContent: this.justifyContent
      }
    }, this.$slots);
  }
});
const colProps = {
  span: {
    type: [String, Number],
    default: 1
  },
  push: {
    type: [String, Number],
    default: 0
  },
  pull: {
    type: [String, Number],
    default: 0
  },
  offset: {
    type: [String, Number],
    default: 0
  }
};
const colPropKeys = keysOf(colProps);
const NCol = defineComponent({
  name: "Col",
  props: colProps,
  setup(props) {
    const NRow2 = inject(rowInjectionKey, null);
    if (!NRow2)
      throwError("col", "`n-col` must be placed inside `n-row`.");
    return {
      mergedClsPrefix: NRow2.mergedClsPrefixRef,
      gutter: NRow2.gutterRef,
      stylePadding: computed(() => `${formatLength(NRow2.verticalGutterRef.value, {
        c: 0.5
      })} ${formatLength(NRow2.horizontalGutterRef.value, {
        c: 0.5
      })}`),
      mergedPush: computed(() => Number(props.push) - Number(props.pull))
    };
  },
  render() {
    const {
      $slots,
      span,
      mergedPush,
      offset,
      stylePadding,
      gutter,
      mergedClsPrefix
    } = this;
    return h("div", {
      class: [`${mergedClsPrefix}-col`, {
        [`${mergedClsPrefix}-col--${span}-span`]: true,
        [`${mergedClsPrefix}-col--${mergedPush}-push`]: mergedPush > 0,
        [`${mergedClsPrefix}-col--${-mergedPush}-pull`]: mergedPush < 0,
        [`${mergedClsPrefix}-col--${offset}-offset`]: offset
      }],
      style: {
        padding: stylePadding
      }
    }, gutter ? h("div", null, $slots) : $slots);
  }
});
const formItemColProps = Object.assign(Object.assign({}, colProps), formItemProps);
const formItemColPropKeys = keysOf(formItemColProps);
const NFormItemCol = defineComponent({
  name: "FormItemCol",
  props: formItemColProps,
  setup() {
    const formItemInstRef = ref(null);
    const validate = (...args) => {
      const {
        value
      } = formItemInstRef;
      if (value) {
        return value.validate(...args);
      }
    };
    const restoreValidation = () => {
      const {
        value
      } = formItemInstRef;
      if (value) {
        value.restoreValidation();
      }
    };
    return {
      formItemInstRef,
      validate,
      restoreValidation
    };
  },
  render() {
    return h(NCol, keep(this.$props, colPropKeys), {
      default: () => {
        const itemProps = keep(this.$props, formItemPropKeys);
        return h(NFormItem, Object.assign({
          ref: "formItemInstRef"
        }, itemProps), this.$slots);
      }
    });
  }
});
const formItemRowProps = Object.assign(Object.assign({}, rowProps), formItemColProps);
const __unplugin_components_5 = defineComponent({
  name: "FormItemRow",
  props: formItemRowProps,
  setup() {
    const formItemColInstRef = ref(null);
    const validate = (...args) => {
      const {
        value
      } = formItemColInstRef;
      if (value) {
        return value.validate(...args);
      }
    };
    const restoreValidation = () => {
      const {
        value
      } = formItemColInstRef;
      if (value) {
        value.restoreValidation();
      }
    };
    return {
      formItemColInstRef,
      validate,
      restoreValidation
    };
  },
  render() {
    return h(NRow, keep(this.$props, rowPropKeys), {
      default: () => {
        const colProps2 = keep(this.$props, formItemColPropKeys);
        return h(NFormItemCol, Object.assign(Object.assign({
          ref: "formItemColInstRef"
        }, colProps2), {
          span: 24
        }), this.$slots);
      }
    });
  }
});
async function login(url, data) {
  const res = await fetch(url + "/api/user/login", {
    headers: {
      "Content-Type": "application/json"
    },
    method: "POST",
    body: JSON.stringify(data)
  });
  return await res.json();
}
async function register(url, data) {
  const res = await fetch(url + "/api/user/register", {
    headers: {
      "Content-Type": "application/json"
    },
    method: "POST",
    body: JSON.stringify(data)
  });
  return await res.json();
}
async function sendCode(url, email) {
  const res = await fetch(url + "/api/code/v1?email=" + email, {
    method: "Get"
  });
  return await res.json();
}
const _imports_0 = "" + buildAssetsURL("wx.B1fgWuP-.png");
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "login",
  __ssrInlineRender: true,
  setup(__props) {
    const router = useRouter();
    const stores = useUserStore();
    const message = useMessage();
    const { public: { api_base_url } } = useRuntimeConfig();
    const is_notice = ref(601);
    const codeTimeInterval = ref(0);
    const codeTimeText = ref("\u53D1\u9001\u9A8C\u8BC1\u7801");
    const codeing = ref(false);
    const registering = ref(false);
    const logining = ref(false);
    const loginForm = ref({
      email: "",
      password: ""
    });
    const registerForm = ref({
      email: "",
      password: "",
      repeat_password: "",
      code: ""
    });
    const onSubmit = async () => {
      var _a;
      const feedback = await ((_a = loginFormRef.value) == null ? void 0 : _a.validate());
      if (!feedback) {
        return;
      }
      logining.value = true;
      const result = await login(api_base_url, loginForm.value);
      logining.value = false;
      if (result.type === "success") {
        stores.token = result.token;
        stores.userinfo = result.data;
        (void 0).localStorage.setItem("token", result.token);
        (void 0).localStorage.setItem("userinfo", JSON.stringify(result.data));
        const result2 = await get_dialog_list(api_base_url, stores.token);
        stores.dialog_contents = result2.contents;
        stores.dialog_titles = result2.titles;
        if (stores.dialog_contents.length > 0) {
          if (stores.userinfo.dialog_id === 1e3) {
            stores.dialog_index = stores.dialog_titles[stores.dialog_titles.length - 1].id;
          } else {
            stores.dialog_index = stores.userinfo.dialog_id;
          }
          stores.dialog_contents.map((item) => {
            if (item.d_id === stores.dialog_index) {
              let temp = {
                role: item.role,
                content: item.content
              };
              stores.dialog_list.push(temp);
            }
          });
          setTimeout(() => {
            stores.rollToTheBottom();
          }, 100);
        }
        message.success(result.message);
        router.push("/");
      } else {
        message.error(result.message);
      }
    };
    const onRegisterSubmit = async () => {
      var _a;
      const feedback = await ((_a = registerFormRef.value) == null ? void 0 : _a.validate());
      if (!feedback) {
        return;
      }
      registering.value = true;
      const res = await register(api_base_url, registerForm.value);
      registering.value = false;
      if (res.type === "success") {
        message.success(res.message);
        registerForm.value.email = "";
        registerForm.value.password = "";
        registerForm.value.repeat_password = "";
        registerForm.value.code = "";
      } else {
        message.error(res.message);
      }
    };
    const onSendCode = async (event) => {
      event.preventDefault();
      const pattern = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
      if (!pattern.test(registerForm.value.email)) {
        message.error("\u8BF7\u8F93\u5165\u6B63\u786E\u7684\u90AE\u7BB1");
        return;
      }
      if (codeTimeInterval.value > 0) {
        return;
      }
      codeing.value = true;
      const res = await sendCode(api_base_url, registerForm.value.email);
      codeing.value = false;
      if (res.type === "success") {
        message.success(res.message);
        codeTimeInterval.value = 60;
        const tempTime = (void 0).setInterval(() => {
          codeTimeInterval.value--;
          (void 0).sessionStorage.setItem("codeTimeInterval", codeTimeInterval.value);
          codeTimeText.value = codeTimeInterval.value + "s";
          if (codeTimeInterval.value <= 0) {
            codeTimeText.value = "\u53D1\u9001\u9A8C\u8BC1\u7801";
            codeTimeInterval.value = 0;
            (void 0).clearInterval(tempTime);
          }
        }, 1e3);
      } else {
        message.error(res.message);
      }
    };
    onUnmounted(() => {
      (void 0).removeEventListener("resize", () => {
      });
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_n_card = __unplugin_components_0$3;
      const _component_n_scrollbar = __unplugin_components_1$1;
      const _component_n_tabs = __unplugin_components_2;
      const _component_n_tab_pane = __unplugin_components_3;
      const _component_n_form = __unplugin_components_4;
      const _component_n_form_item_row = __unplugin_components_5;
      const _component_n_input = __unplugin_components_6;
      const _component_n_button = __unplugin_components_7;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "login-box1" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_n_card, { class: "login-box2" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="login-box3"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_n_card, {
              title: "\u66F4\u65B0\u65E5\u5FD7",
              class: "login-notice"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_n_scrollbar, { style: { "max-height": "400px" } }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<p${_scopeId3}>2024-4-4</p><p${_scopeId3}>1.\u652F\u6301\u591A\u4F1A\u8BDD</p><p${_scopeId3}>2.\u4FEE\u590D\u90E8\u5206bug</p> \u5F00\u6E90\u5730\u5740\uFF1A<a href="https://gitee.com/zmzm666/chatgpt-allai-client" target="_blank"${_scopeId3}>gitee</a>\xA0 <a href="https://github.com/OnZeng/chatgpt-allai-client" target="_blank"${_scopeId3}>github</a><br${_scopeId3}><p${_scopeId3}>\u4EA4\u6D41\u7FA4</p><img style="${ssrRenderStyle({ "width": "100px", "height": "100px" })}"${ssrRenderAttr("src", _imports_0)}${_scopeId3}>`);
                      } else {
                        return [
                          createVNode("p", null, "2024-4-4"),
                          createVNode("p", null, "1.\u652F\u6301\u591A\u4F1A\u8BDD"),
                          createVNode("p", null, "2.\u4FEE\u590D\u90E8\u5206bug"),
                          createTextVNode(" \u5F00\u6E90\u5730\u5740\uFF1A"),
                          createVNode("a", {
                            href: "https://gitee.com/zmzm666/chatgpt-allai-client",
                            target: "_blank"
                          }, "gitee"),
                          createTextVNode("\xA0 "),
                          createVNode("a", {
                            href: "https://github.com/OnZeng/chatgpt-allai-client",
                            target: "_blank"
                          }, "github"),
                          createVNode("br"),
                          createVNode("p", null, "\u4EA4\u6D41\u7FA4"),
                          createVNode("img", {
                            style: { "width": "100px", "height": "100px" },
                            src: _imports_0
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_n_scrollbar, { style: { "max-height": "400px" } }, {
                      default: withCtx(() => [
                        createVNode("p", null, "2024-4-4"),
                        createVNode("p", null, "1.\u652F\u6301\u591A\u4F1A\u8BDD"),
                        createVNode("p", null, "2.\u4FEE\u590D\u90E8\u5206bug"),
                        createTextVNode(" \u5F00\u6E90\u5730\u5740\uFF1A"),
                        createVNode("a", {
                          href: "https://gitee.com/zmzm666/chatgpt-allai-client",
                          target: "_blank"
                        }, "gitee"),
                        createTextVNode("\xA0 "),
                        createVNode("a", {
                          href: "https://github.com/OnZeng/chatgpt-allai-client",
                          target: "_blank"
                        }, "github"),
                        createVNode("br"),
                        createVNode("p", null, "\u4EA4\u6D41\u7FA4"),
                        createVNode("img", {
                          style: { "width": "100px", "height": "100px" },
                          src: _imports_0
                        })
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_n_card, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_n_tabs, {
                    class: "card-tabs",
                    "default-value": "signin",
                    size: "large",
                    animated: "",
                    "pane-wrapper-style": "margin: 0 -4px",
                    "pane-style": "padding-left: 4px; padding-right: 4px; box-sizing: border-box;"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_n_tab_pane, {
                          name: "signin",
                          tab: "\u767B\u5F55"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(_component_n_form, {
                                ref_key: "loginFormRef",
                                ref: loginFormRef,
                                model: unref(loginForm),
                                rules: unref(rules)
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(_component_n_form_item_row, {
                                      label: "\u7528\u6237\u540D",
                                      path: "email"
                                    }, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(ssrRenderComponent(_component_n_input, {
                                            value: unref(loginForm).email,
                                            "onUpdate:value": ($event) => unref(loginForm).email = $event,
                                            placeholder: "\u8F93\u5165\u90AE\u7BB1"
                                          }, null, _parent7, _scopeId6));
                                        } else {
                                          return [
                                            createVNode(_component_n_input, {
                                              value: unref(loginForm).email,
                                              "onUpdate:value": ($event) => unref(loginForm).email = $event,
                                              placeholder: "\u8F93\u5165\u90AE\u7BB1"
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                    _push6(ssrRenderComponent(_component_n_form_item_row, {
                                      label: "\u5BC6\u7801",
                                      path: "password"
                                    }, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(ssrRenderComponent(_component_n_input, {
                                            value: unref(loginForm).password,
                                            "onUpdate:value": ($event) => unref(loginForm).password = $event,
                                            placeholder: "\u8F93\u5165\u5BC6\u7801"
                                          }, null, _parent7, _scopeId6));
                                        } else {
                                          return [
                                            createVNode(_component_n_input, {
                                              value: unref(loginForm).password,
                                              "onUpdate:value": ($event) => unref(loginForm).password = $event,
                                              placeholder: "\u8F93\u5165\u5BC6\u7801"
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(_component_n_form_item_row, {
                                        label: "\u7528\u6237\u540D",
                                        path: "email"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_n_input, {
                                            value: unref(loginForm).email,
                                            "onUpdate:value": ($event) => unref(loginForm).email = $event,
                                            placeholder: "\u8F93\u5165\u90AE\u7BB1"
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_n_form_item_row, {
                                        label: "\u5BC6\u7801",
                                        path: "password"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_n_input, {
                                            value: unref(loginForm).password,
                                            "onUpdate:value": ($event) => unref(loginForm).password = $event,
                                            placeholder: "\u8F93\u5165\u5BC6\u7801"
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(_component_n_button, {
                                type: "primary",
                                block: "",
                                secondary: "",
                                strong: "",
                                onClick: onSubmit,
                                loading: unref(logining)
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(` \u767B\u5F55 `);
                                  } else {
                                    return [
                                      createTextVNode(" \u767B\u5F55 ")
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_component_n_form, {
                                  ref_key: "loginFormRef",
                                  ref: loginFormRef,
                                  model: unref(loginForm),
                                  rules: unref(rules)
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_n_form_item_row, {
                                      label: "\u7528\u6237\u540D",
                                      path: "email"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_n_input, {
                                          value: unref(loginForm).email,
                                          "onUpdate:value": ($event) => unref(loginForm).email = $event,
                                          placeholder: "\u8F93\u5165\u90AE\u7BB1"
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_n_form_item_row, {
                                      label: "\u5BC6\u7801",
                                      path: "password"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_n_input, {
                                          value: unref(loginForm).password,
                                          "onUpdate:value": ($event) => unref(loginForm).password = $event,
                                          placeholder: "\u8F93\u5165\u5BC6\u7801"
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["model", "rules"]),
                                createVNode(_component_n_button, {
                                  type: "primary",
                                  block: "",
                                  secondary: "",
                                  strong: "",
                                  onClick: onSubmit,
                                  loading: unref(logining)
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(" \u767B\u5F55 ")
                                  ]),
                                  _: 1
                                }, 8, ["loading"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(_component_n_tab_pane, {
                          name: "signup",
                          tab: "\u6CE8\u518C"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(_component_n_form, {
                                ref_key: "registerFormRef",
                                ref: registerFormRef,
                                model: unref(registerForm),
                                rules: unref(rules)
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(_component_n_form_item_row, {
                                      label: "\u7528\u6237\u540D",
                                      path: "email"
                                    }, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(ssrRenderComponent(_component_n_input, {
                                            value: unref(registerForm).email,
                                            "onUpdate:value": ($event) => unref(registerForm).email = $event,
                                            placeholder: "\u8F93\u5165\u90AE\u7BB1"
                                          }, null, _parent7, _scopeId6));
                                        } else {
                                          return [
                                            createVNode(_component_n_input, {
                                              value: unref(registerForm).email,
                                              "onUpdate:value": ($event) => unref(registerForm).email = $event,
                                              placeholder: "\u8F93\u5165\u90AE\u7BB1"
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                    _push6(ssrRenderComponent(_component_n_form_item_row, {
                                      label: "\u5BC6\u7801",
                                      path: "password"
                                    }, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(ssrRenderComponent(_component_n_input, {
                                            value: unref(registerForm).password,
                                            "onUpdate:value": ($event) => unref(registerForm).password = $event,
                                            placeholder: "\u8F93\u5165\u5BC6\u7801"
                                          }, null, _parent7, _scopeId6));
                                        } else {
                                          return [
                                            createVNode(_component_n_input, {
                                              value: unref(registerForm).password,
                                              "onUpdate:value": ($event) => unref(registerForm).password = $event,
                                              placeholder: "\u8F93\u5165\u5BC6\u7801"
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                    _push6(ssrRenderComponent(_component_n_form_item_row, {
                                      label: "\u91CD\u590D\u5BC6\u7801",
                                      path: "repeat_password"
                                    }, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(ssrRenderComponent(_component_n_input, {
                                            value: unref(registerForm).repeat_password,
                                            "onUpdate:value": ($event) => unref(registerForm).repeat_password = $event,
                                            placeholder: "\u8F93\u5165\u5BC6\u7801"
                                          }, null, _parent7, _scopeId6));
                                        } else {
                                          return [
                                            createVNode(_component_n_input, {
                                              value: unref(registerForm).repeat_password,
                                              "onUpdate:value": ($event) => unref(registerForm).repeat_password = $event,
                                              placeholder: "\u8F93\u5165\u5BC6\u7801"
                                            }, null, 8, ["value", "onUpdate:value"])
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                    _push6(ssrRenderComponent(_component_n_form_item_row, {
                                      label: "\u9A8C\u8BC1\u7801",
                                      path: "code"
                                    }, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(ssrRenderComponent(_component_n_input, {
                                            value: unref(registerForm).code,
                                            "onUpdate:value": ($event) => unref(registerForm).code = $event,
                                            placeholder: "\u8F93\u5165\u9A8C\u8BC1\u7801"
                                          }, {
                                            suffix: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                              if (_push8) {
                                                _push8(ssrRenderComponent(_component_n_button, {
                                                  type: "primary",
                                                  text: "",
                                                  onClick: onSendCode,
                                                  loading: unref(codeing)
                                                }, {
                                                  default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                    if (_push9) {
                                                      _push9(`${ssrInterpolate(unref(codeTimeText))}`);
                                                    } else {
                                                      return [
                                                        createTextVNode(toDisplayString(unref(codeTimeText)), 1)
                                                      ];
                                                    }
                                                  }),
                                                  _: 1
                                                }, _parent8, _scopeId7));
                                              } else {
                                                return [
                                                  createVNode(_component_n_button, {
                                                    type: "primary",
                                                    text: "",
                                                    onClick: onSendCode,
                                                    loading: unref(codeing)
                                                  }, {
                                                    default: withCtx(() => [
                                                      createTextVNode(toDisplayString(unref(codeTimeText)), 1)
                                                    ]),
                                                    _: 1
                                                  }, 8, ["loading"])
                                                ];
                                              }
                                            }),
                                            _: 1
                                          }, _parent7, _scopeId6));
                                        } else {
                                          return [
                                            createVNode(_component_n_input, {
                                              value: unref(registerForm).code,
                                              "onUpdate:value": ($event) => unref(registerForm).code = $event,
                                              placeholder: "\u8F93\u5165\u9A8C\u8BC1\u7801"
                                            }, {
                                              suffix: withCtx(() => [
                                                createVNode(_component_n_button, {
                                                  type: "primary",
                                                  text: "",
                                                  onClick: onSendCode,
                                                  loading: unref(codeing)
                                                }, {
                                                  default: withCtx(() => [
                                                    createTextVNode(toDisplayString(unref(codeTimeText)), 1)
                                                  ]),
                                                  _: 1
                                                }, 8, ["loading"])
                                              ]),
                                              _: 1
                                            }, 8, ["value", "onUpdate:value"])
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(_component_n_form_item_row, {
                                        label: "\u7528\u6237\u540D",
                                        path: "email"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_n_input, {
                                            value: unref(registerForm).email,
                                            "onUpdate:value": ($event) => unref(registerForm).email = $event,
                                            placeholder: "\u8F93\u5165\u90AE\u7BB1"
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_n_form_item_row, {
                                        label: "\u5BC6\u7801",
                                        path: "password"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_n_input, {
                                            value: unref(registerForm).password,
                                            "onUpdate:value": ($event) => unref(registerForm).password = $event,
                                            placeholder: "\u8F93\u5165\u5BC6\u7801"
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_n_form_item_row, {
                                        label: "\u91CD\u590D\u5BC6\u7801",
                                        path: "repeat_password"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_n_input, {
                                            value: unref(registerForm).repeat_password,
                                            "onUpdate:value": ($event) => unref(registerForm).repeat_password = $event,
                                            placeholder: "\u8F93\u5165\u5BC6\u7801"
                                          }, null, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_n_form_item_row, {
                                        label: "\u9A8C\u8BC1\u7801",
                                        path: "code"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_n_input, {
                                            value: unref(registerForm).code,
                                            "onUpdate:value": ($event) => unref(registerForm).code = $event,
                                            placeholder: "\u8F93\u5165\u9A8C\u8BC1\u7801"
                                          }, {
                                            suffix: withCtx(() => [
                                              createVNode(_component_n_button, {
                                                type: "primary",
                                                text: "",
                                                onClick: onSendCode,
                                                loading: unref(codeing)
                                              }, {
                                                default: withCtx(() => [
                                                  createTextVNode(toDisplayString(unref(codeTimeText)), 1)
                                                ]),
                                                _: 1
                                              }, 8, ["loading"])
                                            ]),
                                            _: 1
                                          }, 8, ["value", "onUpdate:value"])
                                        ]),
                                        _: 1
                                      })
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(_component_n_button, {
                                type: "primary",
                                block: "",
                                secondary: "",
                                strong: "",
                                onClick: onRegisterSubmit,
                                loading: unref(registering)
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(` \u6CE8\u518C `);
                                  } else {
                                    return [
                                      createTextVNode(" \u6CE8\u518C ")
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_component_n_form, {
                                  ref_key: "registerFormRef",
                                  ref: registerFormRef,
                                  model: unref(registerForm),
                                  rules: unref(rules)
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_n_form_item_row, {
                                      label: "\u7528\u6237\u540D",
                                      path: "email"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_n_input, {
                                          value: unref(registerForm).email,
                                          "onUpdate:value": ($event) => unref(registerForm).email = $event,
                                          placeholder: "\u8F93\u5165\u90AE\u7BB1"
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_n_form_item_row, {
                                      label: "\u5BC6\u7801",
                                      path: "password"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_n_input, {
                                          value: unref(registerForm).password,
                                          "onUpdate:value": ($event) => unref(registerForm).password = $event,
                                          placeholder: "\u8F93\u5165\u5BC6\u7801"
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_n_form_item_row, {
                                      label: "\u91CD\u590D\u5BC6\u7801",
                                      path: "repeat_password"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_n_input, {
                                          value: unref(registerForm).repeat_password,
                                          "onUpdate:value": ($event) => unref(registerForm).repeat_password = $event,
                                          placeholder: "\u8F93\u5165\u5BC6\u7801"
                                        }, null, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_n_form_item_row, {
                                      label: "\u9A8C\u8BC1\u7801",
                                      path: "code"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_n_input, {
                                          value: unref(registerForm).code,
                                          "onUpdate:value": ($event) => unref(registerForm).code = $event,
                                          placeholder: "\u8F93\u5165\u9A8C\u8BC1\u7801"
                                        }, {
                                          suffix: withCtx(() => [
                                            createVNode(_component_n_button, {
                                              type: "primary",
                                              text: "",
                                              onClick: onSendCode,
                                              loading: unref(codeing)
                                            }, {
                                              default: withCtx(() => [
                                                createTextVNode(toDisplayString(unref(codeTimeText)), 1)
                                              ]),
                                              _: 1
                                            }, 8, ["loading"])
                                          ]),
                                          _: 1
                                        }, 8, ["value", "onUpdate:value"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                }, 8, ["model", "rules"]),
                                createVNode(_component_n_button, {
                                  type: "primary",
                                  block: "",
                                  secondary: "",
                                  strong: "",
                                  onClick: onRegisterSubmit,
                                  loading: unref(registering)
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode(" \u6CE8\u518C ")
                                  ]),
                                  _: 1
                                }, 8, ["loading"])
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        if (unref(is_notice) < 601) {
                          _push4(ssrRenderComponent(_component_n_tab_pane, {
                            name: "notice",
                            tab: "\u5173\u4E8E"
                          }, {
                            default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                              if (_push5) {
                                _push5(ssrRenderComponent(_component_n_scrollbar, { style: { "max-height": "400px" } }, {
                                  default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                    if (_push6) {
                                      _push6(`<p${_scopeId5}>2024-4-4</p><p${_scopeId5}>1.\u652F\u6301\u591A\u4F1A\u8BDD</p><p${_scopeId5}>2.\u4FEE\u590D\u90E8\u5206bug</p> \u5F00\u6E90\u5730\u5740\uFF1A<a href="https://gitee.com/zmzm666/chatgpt-allai-client" target="_blank"${_scopeId5}>gitee</a>\xA0 <a href="https://github.com/OnZeng/chatgpt-allai-client" target="_blank"${_scopeId5}>github</a><br${_scopeId5}><p${_scopeId5}>\u4EA4\u6D41\u7FA4</p><img style="${ssrRenderStyle({ "width": "100px", "height": "100px" })}"${ssrRenderAttr("src", _imports_0)}${_scopeId5}>`);
                                    } else {
                                      return [
                                        createVNode("p", null, "2024-4-4"),
                                        createVNode("p", null, "1.\u652F\u6301\u591A\u4F1A\u8BDD"),
                                        createVNode("p", null, "2.\u4FEE\u590D\u90E8\u5206bug"),
                                        createTextVNode(" \u5F00\u6E90\u5730\u5740\uFF1A"),
                                        createVNode("a", {
                                          href: "https://gitee.com/zmzm666/chatgpt-allai-client",
                                          target: "_blank"
                                        }, "gitee"),
                                        createTextVNode("\xA0 "),
                                        createVNode("a", {
                                          href: "https://github.com/OnZeng/chatgpt-allai-client",
                                          target: "_blank"
                                        }, "github"),
                                        createVNode("br"),
                                        createVNode("p", null, "\u4EA4\u6D41\u7FA4"),
                                        createVNode("img", {
                                          style: { "width": "100px", "height": "100px" },
                                          src: _imports_0
                                        })
                                      ];
                                    }
                                  }),
                                  _: 1
                                }, _parent5, _scopeId4));
                              } else {
                                return [
                                  createVNode(_component_n_scrollbar, { style: { "max-height": "400px" } }, {
                                    default: withCtx(() => [
                                      createVNode("p", null, "2024-4-4"),
                                      createVNode("p", null, "1.\u652F\u6301\u591A\u4F1A\u8BDD"),
                                      createVNode("p", null, "2.\u4FEE\u590D\u90E8\u5206bug"),
                                      createTextVNode(" \u5F00\u6E90\u5730\u5740\uFF1A"),
                                      createVNode("a", {
                                        href: "https://gitee.com/zmzm666/chatgpt-allai-client",
                                        target: "_blank"
                                      }, "gitee"),
                                      createTextVNode("\xA0 "),
                                      createVNode("a", {
                                        href: "https://github.com/OnZeng/chatgpt-allai-client",
                                        target: "_blank"
                                      }, "github"),
                                      createVNode("br"),
                                      createVNode("p", null, "\u4EA4\u6D41\u7FA4"),
                                      createVNode("img", {
                                        style: { "width": "100px", "height": "100px" },
                                        src: _imports_0
                                      })
                                    ]),
                                    _: 1
                                  })
                                ];
                              }
                            }),
                            _: 1
                          }, _parent4, _scopeId3));
                        } else {
                          _push4(`<!---->`);
                        }
                      } else {
                        return [
                          createVNode(_component_n_tab_pane, {
                            name: "signin",
                            tab: "\u767B\u5F55"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_n_form, {
                                ref_key: "loginFormRef",
                                ref: loginFormRef,
                                model: unref(loginForm),
                                rules: unref(rules)
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_n_form_item_row, {
                                    label: "\u7528\u6237\u540D",
                                    path: "email"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_n_input, {
                                        value: unref(loginForm).email,
                                        "onUpdate:value": ($event) => unref(loginForm).email = $event,
                                        placeholder: "\u8F93\u5165\u90AE\u7BB1"
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_n_form_item_row, {
                                    label: "\u5BC6\u7801",
                                    path: "password"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_n_input, {
                                        value: unref(loginForm).password,
                                        "onUpdate:value": ($event) => unref(loginForm).password = $event,
                                        placeholder: "\u8F93\u5165\u5BC6\u7801"
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["model", "rules"]),
                              createVNode(_component_n_button, {
                                type: "primary",
                                block: "",
                                secondary: "",
                                strong: "",
                                onClick: onSubmit,
                                loading: unref(logining)
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(" \u767B\u5F55 ")
                                ]),
                                _: 1
                              }, 8, ["loading"])
                            ]),
                            _: 1
                          }),
                          createVNode(_component_n_tab_pane, {
                            name: "signup",
                            tab: "\u6CE8\u518C"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_n_form, {
                                ref_key: "registerFormRef",
                                ref: registerFormRef,
                                model: unref(registerForm),
                                rules: unref(rules)
                              }, {
                                default: withCtx(() => [
                                  createVNode(_component_n_form_item_row, {
                                    label: "\u7528\u6237\u540D",
                                    path: "email"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_n_input, {
                                        value: unref(registerForm).email,
                                        "onUpdate:value": ($event) => unref(registerForm).email = $event,
                                        placeholder: "\u8F93\u5165\u90AE\u7BB1"
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_n_form_item_row, {
                                    label: "\u5BC6\u7801",
                                    path: "password"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_n_input, {
                                        value: unref(registerForm).password,
                                        "onUpdate:value": ($event) => unref(registerForm).password = $event,
                                        placeholder: "\u8F93\u5165\u5BC6\u7801"
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_n_form_item_row, {
                                    label: "\u91CD\u590D\u5BC6\u7801",
                                    path: "repeat_password"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_n_input, {
                                        value: unref(registerForm).repeat_password,
                                        "onUpdate:value": ($event) => unref(registerForm).repeat_password = $event,
                                        placeholder: "\u8F93\u5165\u5BC6\u7801"
                                      }, null, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_n_form_item_row, {
                                    label: "\u9A8C\u8BC1\u7801",
                                    path: "code"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_n_input, {
                                        value: unref(registerForm).code,
                                        "onUpdate:value": ($event) => unref(registerForm).code = $event,
                                        placeholder: "\u8F93\u5165\u9A8C\u8BC1\u7801"
                                      }, {
                                        suffix: withCtx(() => [
                                          createVNode(_component_n_button, {
                                            type: "primary",
                                            text: "",
                                            onClick: onSendCode,
                                            loading: unref(codeing)
                                          }, {
                                            default: withCtx(() => [
                                              createTextVNode(toDisplayString(unref(codeTimeText)), 1)
                                            ]),
                                            _: 1
                                          }, 8, ["loading"])
                                        ]),
                                        _: 1
                                      }, 8, ["value", "onUpdate:value"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              }, 8, ["model", "rules"]),
                              createVNode(_component_n_button, {
                                type: "primary",
                                block: "",
                                secondary: "",
                                strong: "",
                                onClick: onRegisterSubmit,
                                loading: unref(registering)
                              }, {
                                default: withCtx(() => [
                                  createTextVNode(" \u6CE8\u518C ")
                                ]),
                                _: 1
                              }, 8, ["loading"])
                            ]),
                            _: 1
                          }),
                          unref(is_notice) < 601 ? (openBlock(), createBlock(_component_n_tab_pane, {
                            key: 0,
                            name: "notice",
                            tab: "\u5173\u4E8E"
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_n_scrollbar, { style: { "max-height": "400px" } }, {
                                default: withCtx(() => [
                                  createVNode("p", null, "2024-4-4"),
                                  createVNode("p", null, "1.\u652F\u6301\u591A\u4F1A\u8BDD"),
                                  createVNode("p", null, "2.\u4FEE\u590D\u90E8\u5206bug"),
                                  createTextVNode(" \u5F00\u6E90\u5730\u5740\uFF1A"),
                                  createVNode("a", {
                                    href: "https://gitee.com/zmzm666/chatgpt-allai-client",
                                    target: "_blank"
                                  }, "gitee"),
                                  createTextVNode("\xA0 "),
                                  createVNode("a", {
                                    href: "https://github.com/OnZeng/chatgpt-allai-client",
                                    target: "_blank"
                                  }, "github"),
                                  createVNode("br"),
                                  createVNode("p", null, "\u4EA4\u6D41\u7FA4"),
                                  createVNode("img", {
                                    style: { "width": "100px", "height": "100px" },
                                    src: _imports_0
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })) : createCommentVNode("", true)
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_n_tabs, {
                      class: "card-tabs",
                      "default-value": "signin",
                      size: "large",
                      animated: "",
                      "pane-wrapper-style": "margin: 0 -4px",
                      "pane-style": "padding-left: 4px; padding-right: 4px; box-sizing: border-box;"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_n_tab_pane, {
                          name: "signin",
                          tab: "\u767B\u5F55"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_n_form, {
                              ref_key: "loginFormRef",
                              ref: loginFormRef,
                              model: unref(loginForm),
                              rules: unref(rules)
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_n_form_item_row, {
                                  label: "\u7528\u6237\u540D",
                                  path: "email"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_n_input, {
                                      value: unref(loginForm).email,
                                      "onUpdate:value": ($event) => unref(loginForm).email = $event,
                                      placeholder: "\u8F93\u5165\u90AE\u7BB1"
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_n_form_item_row, {
                                  label: "\u5BC6\u7801",
                                  path: "password"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_n_input, {
                                      value: unref(loginForm).password,
                                      "onUpdate:value": ($event) => unref(loginForm).password = $event,
                                      placeholder: "\u8F93\u5165\u5BC6\u7801"
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["model", "rules"]),
                            createVNode(_component_n_button, {
                              type: "primary",
                              block: "",
                              secondary: "",
                              strong: "",
                              onClick: onSubmit,
                              loading: unref(logining)
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" \u767B\u5F55 ")
                              ]),
                              _: 1
                            }, 8, ["loading"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_n_tab_pane, {
                          name: "signup",
                          tab: "\u6CE8\u518C"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_n_form, {
                              ref_key: "registerFormRef",
                              ref: registerFormRef,
                              model: unref(registerForm),
                              rules: unref(rules)
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_n_form_item_row, {
                                  label: "\u7528\u6237\u540D",
                                  path: "email"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_n_input, {
                                      value: unref(registerForm).email,
                                      "onUpdate:value": ($event) => unref(registerForm).email = $event,
                                      placeholder: "\u8F93\u5165\u90AE\u7BB1"
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_n_form_item_row, {
                                  label: "\u5BC6\u7801",
                                  path: "password"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_n_input, {
                                      value: unref(registerForm).password,
                                      "onUpdate:value": ($event) => unref(registerForm).password = $event,
                                      placeholder: "\u8F93\u5165\u5BC6\u7801"
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_n_form_item_row, {
                                  label: "\u91CD\u590D\u5BC6\u7801",
                                  path: "repeat_password"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_n_input, {
                                      value: unref(registerForm).repeat_password,
                                      "onUpdate:value": ($event) => unref(registerForm).repeat_password = $event,
                                      placeholder: "\u8F93\u5165\u5BC6\u7801"
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_n_form_item_row, {
                                  label: "\u9A8C\u8BC1\u7801",
                                  path: "code"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_n_input, {
                                      value: unref(registerForm).code,
                                      "onUpdate:value": ($event) => unref(registerForm).code = $event,
                                      placeholder: "\u8F93\u5165\u9A8C\u8BC1\u7801"
                                    }, {
                                      suffix: withCtx(() => [
                                        createVNode(_component_n_button, {
                                          type: "primary",
                                          text: "",
                                          onClick: onSendCode,
                                          loading: unref(codeing)
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode(toDisplayString(unref(codeTimeText)), 1)
                                          ]),
                                          _: 1
                                        }, 8, ["loading"])
                                      ]),
                                      _: 1
                                    }, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["model", "rules"]),
                            createVNode(_component_n_button, {
                              type: "primary",
                              block: "",
                              secondary: "",
                              strong: "",
                              onClick: onRegisterSubmit,
                              loading: unref(registering)
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" \u6CE8\u518C ")
                              ]),
                              _: 1
                            }, 8, ["loading"])
                          ]),
                          _: 1
                        }),
                        unref(is_notice) < 601 ? (openBlock(), createBlock(_component_n_tab_pane, {
                          key: 0,
                          name: "notice",
                          tab: "\u5173\u4E8E"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_n_scrollbar, { style: { "max-height": "400px" } }, {
                              default: withCtx(() => [
                                createVNode("p", null, "2024-4-4"),
                                createVNode("p", null, "1.\u652F\u6301\u591A\u4F1A\u8BDD"),
                                createVNode("p", null, "2.\u4FEE\u590D\u90E8\u5206bug"),
                                createTextVNode(" \u5F00\u6E90\u5730\u5740\uFF1A"),
                                createVNode("a", {
                                  href: "https://gitee.com/zmzm666/chatgpt-allai-client",
                                  target: "_blank"
                                }, "gitee"),
                                createTextVNode("\xA0 "),
                                createVNode("a", {
                                  href: "https://github.com/OnZeng/chatgpt-allai-client",
                                  target: "_blank"
                                }, "github"),
                                createVNode("br"),
                                createVNode("p", null, "\u4EA4\u6D41\u7FA4"),
                                createVNode("img", {
                                  style: { "width": "100px", "height": "100px" },
                                  src: _imports_0
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })) : createCommentVNode("", true)
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "login-box3" }, [
                createVNode(_component_n_card, {
                  title: "\u66F4\u65B0\u65E5\u5FD7",
                  class: "login-notice"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_n_scrollbar, { style: { "max-height": "400px" } }, {
                      default: withCtx(() => [
                        createVNode("p", null, "2024-4-4"),
                        createVNode("p", null, "1.\u652F\u6301\u591A\u4F1A\u8BDD"),
                        createVNode("p", null, "2.\u4FEE\u590D\u90E8\u5206bug"),
                        createTextVNode(" \u5F00\u6E90\u5730\u5740\uFF1A"),
                        createVNode("a", {
                          href: "https://gitee.com/zmzm666/chatgpt-allai-client",
                          target: "_blank"
                        }, "gitee"),
                        createTextVNode("\xA0 "),
                        createVNode("a", {
                          href: "https://github.com/OnZeng/chatgpt-allai-client",
                          target: "_blank"
                        }, "github"),
                        createVNode("br"),
                        createVNode("p", null, "\u4EA4\u6D41\u7FA4"),
                        createVNode("img", {
                          style: { "width": "100px", "height": "100px" },
                          src: _imports_0
                        })
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                }),
                createVNode(_component_n_card, null, {
                  default: withCtx(() => [
                    createVNode(_component_n_tabs, {
                      class: "card-tabs",
                      "default-value": "signin",
                      size: "large",
                      animated: "",
                      "pane-wrapper-style": "margin: 0 -4px",
                      "pane-style": "padding-left: 4px; padding-right: 4px; box-sizing: border-box;"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_n_tab_pane, {
                          name: "signin",
                          tab: "\u767B\u5F55"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_n_form, {
                              ref_key: "loginFormRef",
                              ref: loginFormRef,
                              model: unref(loginForm),
                              rules: unref(rules)
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_n_form_item_row, {
                                  label: "\u7528\u6237\u540D",
                                  path: "email"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_n_input, {
                                      value: unref(loginForm).email,
                                      "onUpdate:value": ($event) => unref(loginForm).email = $event,
                                      placeholder: "\u8F93\u5165\u90AE\u7BB1"
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_n_form_item_row, {
                                  label: "\u5BC6\u7801",
                                  path: "password"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_n_input, {
                                      value: unref(loginForm).password,
                                      "onUpdate:value": ($event) => unref(loginForm).password = $event,
                                      placeholder: "\u8F93\u5165\u5BC6\u7801"
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["model", "rules"]),
                            createVNode(_component_n_button, {
                              type: "primary",
                              block: "",
                              secondary: "",
                              strong: "",
                              onClick: onSubmit,
                              loading: unref(logining)
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" \u767B\u5F55 ")
                              ]),
                              _: 1
                            }, 8, ["loading"])
                          ]),
                          _: 1
                        }),
                        createVNode(_component_n_tab_pane, {
                          name: "signup",
                          tab: "\u6CE8\u518C"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_n_form, {
                              ref_key: "registerFormRef",
                              ref: registerFormRef,
                              model: unref(registerForm),
                              rules: unref(rules)
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_n_form_item_row, {
                                  label: "\u7528\u6237\u540D",
                                  path: "email"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_n_input, {
                                      value: unref(registerForm).email,
                                      "onUpdate:value": ($event) => unref(registerForm).email = $event,
                                      placeholder: "\u8F93\u5165\u90AE\u7BB1"
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_n_form_item_row, {
                                  label: "\u5BC6\u7801",
                                  path: "password"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_n_input, {
                                      value: unref(registerForm).password,
                                      "onUpdate:value": ($event) => unref(registerForm).password = $event,
                                      placeholder: "\u8F93\u5165\u5BC6\u7801"
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_n_form_item_row, {
                                  label: "\u91CD\u590D\u5BC6\u7801",
                                  path: "repeat_password"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_n_input, {
                                      value: unref(registerForm).repeat_password,
                                      "onUpdate:value": ($event) => unref(registerForm).repeat_password = $event,
                                      placeholder: "\u8F93\u5165\u5BC6\u7801"
                                    }, null, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_n_form_item_row, {
                                  label: "\u9A8C\u8BC1\u7801",
                                  path: "code"
                                }, {
                                  default: withCtx(() => [
                                    createVNode(_component_n_input, {
                                      value: unref(registerForm).code,
                                      "onUpdate:value": ($event) => unref(registerForm).code = $event,
                                      placeholder: "\u8F93\u5165\u9A8C\u8BC1\u7801"
                                    }, {
                                      suffix: withCtx(() => [
                                        createVNode(_component_n_button, {
                                          type: "primary",
                                          text: "",
                                          onClick: onSendCode,
                                          loading: unref(codeing)
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode(toDisplayString(unref(codeTimeText)), 1)
                                          ]),
                                          _: 1
                                        }, 8, ["loading"])
                                      ]),
                                      _: 1
                                    }, 8, ["value", "onUpdate:value"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["model", "rules"]),
                            createVNode(_component_n_button, {
                              type: "primary",
                              block: "",
                              secondary: "",
                              strong: "",
                              onClick: onRegisterSubmit,
                              loading: unref(registering)
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" \u6CE8\u518C ")
                              ]),
                              _: 1
                            }, 8, ["loading"])
                          ]),
                          _: 1
                        }),
                        unref(is_notice) < 601 ? (openBlock(), createBlock(_component_n_tab_pane, {
                          key: 0,
                          name: "notice",
                          tab: "\u5173\u4E8E"
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_n_scrollbar, { style: { "max-height": "400px" } }, {
                              default: withCtx(() => [
                                createVNode("p", null, "2024-4-4"),
                                createVNode("p", null, "1.\u652F\u6301\u591A\u4F1A\u8BDD"),
                                createVNode("p", null, "2.\u4FEE\u590D\u90E8\u5206bug"),
                                createTextVNode(" \u5F00\u6E90\u5730\u5740\uFF1A"),
                                createVNode("a", {
                                  href: "https://gitee.com/zmzm666/chatgpt-allai-client",
                                  target: "_blank"
                                }, "gitee"),
                                createTextVNode("\xA0 "),
                                createVNode("a", {
                                  href: "https://github.com/OnZeng/chatgpt-allai-client",
                                  target: "_blank"
                                }, "github"),
                                createVNode("br"),
                                createVNode("p", null, "\u4EA4\u6D41\u7FA4"),
                                createVNode("img", {
                                  style: { "width": "100px", "height": "100px" },
                                  src: _imports_0
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })) : createCommentVNode("", true)
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/login.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=login-1ojIUY2J.mjs.map
