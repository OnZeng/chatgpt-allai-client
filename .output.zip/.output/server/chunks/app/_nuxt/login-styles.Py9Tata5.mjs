const login = ".login-box1{align-items:center;display:flex;height:100%;justify-content:center;width:100%}.login-box2{height:550px;max-width:1024px}.login-box3{display:flex;gap:0 10px;height:100%;justify-content:space-between;width:100%}@media screen and (max-width:1072px){.login-box2{width:95%}}@media screen and (max-width:600px){.login-notice{display:none}.login-notice2{display:block}}";

const loginStyles_Py9Tata5 = [login];

export { loginStyles_Py9Tata5 as default };
//# sourceMappingURL=login-styles.Py9Tata5.mjs.map
