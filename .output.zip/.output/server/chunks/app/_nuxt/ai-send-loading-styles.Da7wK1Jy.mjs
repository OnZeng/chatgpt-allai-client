const sendLoading = ".sendLoading-box1{bottom:50px;flex-direction:column;gap:6px;height:80px;margin:0 auto;position:fixed;width:100%}.loader,.sendLoading-box1{align-items:center;display:flex;justify-content:center}.loader{margin-top:5px}.loader-dot{animation:loader-animation 1.5s ease-in-out infinite;background-color:#18a058;border-radius:50%;height:10px;margin:0 10px;width:10px}.loader-dot:nth-child(2){animation-delay:.25s}.loader-dot:nth-child(3){animation-delay:.5s}@keyframes loader-animation{0%{transform:scale(0)}50%{transform:scale(1)}to{transform:scale(0)}}@media screen and (max-width:1300px){.sendLoading-box1{bottom:25px}}@media screen and (max-width:600px){.sendLoading-box1{bottom:23px}}";

const aiSendLoadingStyles_Da7wK1Jy = [sendLoading];

export { aiSendLoadingStyles_Da7wK1Jy as default };
//# sourceMappingURL=ai-send-loading-styles.Da7wK1Jy.mjs.map
