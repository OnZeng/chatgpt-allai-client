const index = "";

const indexStyles_BLM4YAtd = [index];

export { indexStyles_BLM4YAtd as default };
//# sourceMappingURL=index-styles.BLM4YAtd.mjs.map
