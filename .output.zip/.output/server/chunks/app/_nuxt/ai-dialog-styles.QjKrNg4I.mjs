const aiDialog_vue_vue_type_style_index_0_scoped_374f9fdc_lang = "[data-v-374f9fdc]  .pre-code-header{background-color:#343541;color:#fff;display:flex;justify-content:space-between;position:relative;width:100%}[data-v-374f9fdc]  .code-block-header__copy{cursor:pointer;position:absolute;right:4px}[data-v-374f9fdc]  .code-block-header__lang{margin-left:4px}";

const aiDialogStyles_QjKrNg4I = [aiDialog_vue_vue_type_style_index_0_scoped_374f9fdc_lang];

export { aiDialogStyles_QjKrNg4I as default };
//# sourceMappingURL=ai-dialog-styles.QjKrNg4I.mjs.map
