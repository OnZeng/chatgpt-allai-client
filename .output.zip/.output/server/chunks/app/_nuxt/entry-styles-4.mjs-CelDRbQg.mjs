const app = "#__layout,#__nuxt,body,html{height:100%;margin:0;padding:0;width:100%}.app{height:100%;width:100%}";

export { app as a };
//# sourceMappingURL=entry-styles-4.mjs-CelDRbQg.mjs.map
