import { useSSRContext, defineComponent, unref, mergeProps, withCtx, createVNode, toDisplayString, createTextVNode } from 'vue';
import { ssrRenderComponent, ssrRenderAttrs, ssrRenderList, ssrInterpolate, ssrRenderClass, ssrRenderAttr } from 'vue/server-renderer';
import { d as useUserStore, _ as __unplugin_components_0$3, e as __unplugin_components_7 } from '../server.mjs';
import MarkdownIt from 'markdown-it';
import mdKatex from '@traptitech/markdown-it-katex';
import hljs from 'highlight.js';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import { _ as __unplugin_components_6 } from './Input-D2_8YhdT.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'seemly';
import 'css-render';
import 'lodash-es';
import 'vooks';
import '@vicons/ionicons5';
import 'evtd';
import 'treemate';
import 'vdirs';

const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "ai-home",
  __ssrInlineRender: true,
  setup(__props) {
    const stores = useUserStore();
    const go = (item) => {
      stores.myinfo.content = item.content;
      stores.handleEnter(event);
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_n_card = __unplugin_components_0$3;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "h-box1" }, _attrs))}><div class="h-box3"><!--[-->`);
      ssrRenderList(unref(stores).list, (item, index) => {
        _push(ssrRenderComponent(_component_n_card, {
          key: index,
          class: "h-box4",
          onClick: ($event) => go(item),
          hoverable: ""
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="h-box4-title"${_scopeId}>${ssrInterpolate(item.role)}</div><div class="h-box4-content"${_scopeId}>${ssrInterpolate(item.content)}</div>`);
            } else {
              return [
                createVNode("div", { class: "h-box4-title" }, toDisplayString(item.role), 1),
                createVNode("div", { class: "h-box4-content" }, toDisplayString(item.content), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
      });
      _push(`<!--]--></div></div>`);
    };
  }
});
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ai-home.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "ai-dialog",
  __ssrInlineRender: true,
  setup(__props) {
    const stores = useUserStore();
    const mdi = new MarkdownIt({
      linkify: true,
      highlight(code, language) {
        const codeIndex = Date.now() + Math.floor(Math.random() * 1e7);
        const validLang = !!(language && hljs.getLanguage(language));
        if (validLang) {
          const lang = language != null ? language : "";
          return highlightBlock(
            hljs.highlight(lang, code, true).value,
            lang,
            codeIndex
          );
        }
        return highlightBlock(hljs.highlightAuto(code).value, "", codeIndex);
      }
    });
    mdi.use(mdKatex, {
      blockClass: "katexmath-block rounded-md p-[0px]",
      errorColor: " #cc0000"
    });
    function highlightBlock(str, lang, codeIndex) {
      return `<pre class="pre-code-box"><div class="pre-code-header"><span class="code-block-header__lang">${lang}</span><span class="code-block-header__copy" data-clipboard-action="copy" data-clipboard-target="#copy${codeIndex}">\u590D\u5236\u4EE3\u7801</span></div><div class="pre-code" id="copy${codeIndex}"><code class="hljs code-block-body ${lang}">${str}</code></div></pre>`;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_n_card = __unplugin_components_0$3;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "d-box1" }, _attrs))} data-v-374f9fdc><div class="d-box2" id="el" data-v-374f9fdc><!--[-->`);
      ssrRenderList(unref(stores).dialog_list, (item) => {
        _push(`<div class="${ssrRenderClass([item.role == unref(stores).myinfo.role ? "d-right" : "d-left"])}" data-v-374f9fdc><div class="d-box3" data-v-374f9fdc><img class="d-img1"${ssrRenderAttr("src", item.role == unref(stores).myinfo.role ? unref(stores).account.Avatar : unref(stores).account.AI_Icon)} data-v-374f9fdc></div>`);
        if (item.role == unref(stores).myinfo.role ? false : true) {
          _push(ssrRenderComponent(_component_n_card, {
            class: [item.role == unref(stores).myinfo.role ? "d-right-style" : "d-left-style"]
          }, null, _parent));
        } else {
          _push(ssrRenderComponent(_component_n_card, {
            class: [item.role == unref(stores).myinfo.role ? "d-right-style" : "d-left-style"]
          }, null, _parent));
        }
        _push(`</div>`);
      });
      _push(`<!--]--></div></div>`);
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ai-dialog.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-374f9fdc"]]);
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "ai-send",
  __ssrInlineRender: true,
  setup(__props) {
    const stores = useUserStore();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_n_input = __unplugin_components_6;
      const _component_n_button = __unplugin_components_7;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "send-box1" }, _attrs))}><div class="send-box2">`);
      _push(ssrRenderComponent(_component_n_input, {
        value: unref(stores).myinfo.content,
        "onUpdate:value": ($event) => unref(stores).myinfo.content = $event,
        placeholder: '\u6709\u95EE\u9898\u5C3D\u7BA1\u95EE\u6211...\uFF08Shift + Enter = \u6362\u884C\uFF0C"/" \u89E6\u53D1\u63D0\u793A\u8BCD\uFF09',
        type: "textarea",
        autosize: {
          minRows: 1,
          maxRows: 5
        },
        onKeydown: unref(stores).handleEnter,
        onFocus: unref(stores).checkLogin
      }, null, _parent));
      _push(ssrRenderComponent(_component_n_button, {
        type: "primary",
        onClick: unref(stores).handleEnter
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` \u53D1\u9001 `);
          } else {
            return [
              createTextVNode(" \u53D1\u9001 ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ai-send.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "ai-send-loading",
  __ssrInlineRender: true,
  setup(__props) {
    const stores = useUserStore();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_n_button = __unplugin_components_7;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "sendLoading-box1" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_n_button, {
        type: "error",
        onClick: unref(stores).stopAnswer
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` \u505C\u6B62\u54CD\u5E94 `);
          } else {
            return [
              createTextVNode(" \u505C\u6B62\u54CD\u5E94 ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="loader"><div class="loader-dot"></div><div class="loader-dot"></div><div class="loader-dot"></div></div></div>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ai-send-loading.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const stores = useUserStore();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ai_home = _sfc_main$4;
      const _component_ai_dialog = __nuxt_component_1;
      const _component_ai_send = _sfc_main$2;
      const _component_ai_send_loading = _sfc_main$1;
      _push(`<!--[-->`);
      if (unref(stores).dialog_list.length === 0) {
        _push(ssrRenderComponent(_component_ai_home, null, null, _parent));
      } else {
        _push(ssrRenderComponent(_component_ai_dialog, null, null, _parent));
      }
      if (unref(stores).dialog_is) {
        _push(ssrRenderComponent(_component_ai_send, null, null, _parent));
      } else {
        _push(ssrRenderComponent(_component_ai_send_loading, null, null, _parent));
      }
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-TxqAY6my.mjs.map
