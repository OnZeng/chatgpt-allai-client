import { s as setting } from './entry-styles-2.mjs-BkZBxRXF.mjs';

const aiSettingStyles_DTRAGxXI = [setting];

export { aiSettingStyles_DTRAGxXI as default };
//# sourceMappingURL=ai-setting-styles.DTRAGxXI.mjs.map
