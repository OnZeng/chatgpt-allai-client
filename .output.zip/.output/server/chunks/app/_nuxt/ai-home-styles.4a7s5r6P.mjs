const home = ".h-box1{align-items:center;display:flex;flex-direction:column;height:100%;justify-content:center;width:100%}.h-box3{display:flex;gap:40px}.h-box4{cursor:pointer;flex:1}.h-box4-title{text-align:center}@media screen and (max-width:1100px){.h-box3{gap:10px}.h-box4{border:1px solid #dcdcdc;border-radius:3px;box-sizing:border-box;cursor:pointer;display:flex;flex:1;max-height:195px;min-height:105px}}@media screen and (max-width:1050px){.h-box3{flex-direction:column;gap:20px}.h-box4{border:1px solid #dcdcdc;border-radius:3px;box-sizing:border-box;cursor:pointer;display:flex;flex:1;max-height:195px;min-height:105px;padding:20px}}@media screen and (max-width:450px){.h-box3{width:95%}.h-box4{padding:0}}";

const aiHomeStyles_4a7s5r6P = [home];

export { aiHomeStyles_4a7s5r6P as default };
//# sourceMappingURL=ai-home-styles.4a7s5r6P.mjs.map
