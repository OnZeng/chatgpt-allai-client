const setting = ".s-box1{display:flex;justify-content:space-between;pointer-events:none;position:fixed;width:100%;z-index:100}.s-box2{margin-left:20px}.s-box2,.s-box3{cursor:pointer;margin-top:20px;padding:5px;pointer-events:auto}.s-box3{margin-right:20px}";

export { setting as s };
//# sourceMappingURL=entry-styles-2.mjs-BkZBxRXF.mjs.map
