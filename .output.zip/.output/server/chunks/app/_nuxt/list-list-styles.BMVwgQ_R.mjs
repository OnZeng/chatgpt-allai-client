import { l as listList } from './entry-styles-1.mjs-D9Gg5EBO.mjs';

const listListStyles_BMVwgQ_R = [listList];

export { listListStyles_BMVwgQ_R as default };
//# sourceMappingURL=list-list-styles.BMVwgQ_R.mjs.map
