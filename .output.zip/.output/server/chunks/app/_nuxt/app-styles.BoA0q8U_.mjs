import { a as app } from './entry-styles-4.mjs-CelDRbQg.mjs';

const appStyles_BoA0q8U_ = [app];

export { appStyles_BoA0q8U_ as default };
//# sourceMappingURL=app-styles.BoA0q8U_.mjs.map
