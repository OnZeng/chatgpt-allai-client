const interopDefault = r => r.default || r || [];
const styles = {
  "node_modules/nuxt/dist/app/entry.js": () => import('./_nuxt/entry-styles._RCASPme.mjs').then(interopDefault),
  "pages/index.vue?vue&type=script&setup=true&lang.ts": () => import('./_nuxt/index-styles.BLM4YAtd.mjs').then(interopDefault),
  "pages/login.vue?vue&type=script&setup=true&lang.ts": () => import('./_nuxt/login-styles.Py9Tata5.mjs').then(interopDefault),
  "app.vue?vue&type=script&setup=true&lang.ts": () => import('./_nuxt/app-styles.BoA0q8U_.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": () => import('./_nuxt/error-404-styles.DKrRPVnW.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": () => import('./_nuxt/error-500-styles.TTVQqs5q.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue?vue&type=style&index=0&scoped=ccd3db62&lang.css": () => import('./_nuxt/error-404-styles.DKrRPVnW.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue?vue&type=style&index=0&scoped=df79c84d&lang.css": () => import('./_nuxt/error-500-styles.TTVQqs5q.mjs').then(interopDefault),
  "components/ai-dialog.vue": () => import('./_nuxt/ai-dialog-styles.QjKrNg4I.mjs').then(interopDefault),
  "components/ai-dialog.vue?vue&type=style&index=0&scoped=374f9fdc&lang.css": () => import('./_nuxt/ai-dialog-styles.QjKrNg4I.mjs').then(interopDefault),
  "components/ai-send-loading.vue?vue&type=script&setup=true&lang.ts": () => import('./_nuxt/ai-send-loading-styles.Da7wK1Jy.mjs').then(interopDefault),
  "components/ai-home.vue?vue&type=script&setup=true&lang.ts": () => import('./_nuxt/ai-home-styles.4a7s5r6P.mjs').then(interopDefault),
  "components/ai-send.vue?vue&type=script&setup=true&lang.ts": () => import('./_nuxt/ai-send-styles.D62z-0M8.mjs').then(interopDefault),
  "components/ai-dialog.vue?vue&type=script&setup=true&lang.ts": () => import('./_nuxt/ai-dialog-styles.VZjYWa6J.mjs').then(interopDefault),
  "components/ai-setting.vue?vue&type=script&setup=true&lang.ts": () => import('./_nuxt/ai-setting-styles.DTRAGxXI.mjs').then(interopDefault),
  "components/ai-loading.vue?vue&type=script&setup=true&lang.ts": () => import('./_nuxt/ai-loading-styles.zd9dSYp5.mjs').then(interopDefault),
  "components/lists/list-list.vue?vue&type=script&setup=true&lang.ts": () => import('./_nuxt/list-list-styles.BMVwgQ_R.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
