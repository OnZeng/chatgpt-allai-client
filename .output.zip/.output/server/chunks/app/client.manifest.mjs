const client_manifest = {
  "_Input.CD2kiVdc.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Input.CD2kiVdc.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "__plugin-vue_export-helper.DlAUqK2U.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_plugin-vue_export-helper.DlAUqK2U.js"
  },
  "_vue.f36acd1f.DLHy-ZFk.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vue.f36acd1f.DLHy-ZFk.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "images/wx.png": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png",
    "file": "wx.B1fgWuP-.png",
    "src": "images/wx.png"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "default.CUJH44j-.js",
    "src": "layouts/default.vue",
    "isDynamicEntry": true,
    "imports": [
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "error-404.BR0f6BYD.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_vue.f36acd1f.DLHy-ZFk.js",
      "__plugin-vue_export-helper.DlAUqK2U.js"
    ],
    "css": []
  },
  "error-404.CoUbADi5.css": {
    "file": "error-404.CoUbADi5.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "error-500.DdgPJbnx.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue",
    "isDynamicEntry": true,
    "imports": [
      "_vue.f36acd1f.DLHy-ZFk.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": []
  },
  "error-500.BXQ_YkC0.css": {
    "file": "error-500.BXQ_YkC0.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "entry.h8zsK0we.js",
    "src": "node_modules/nuxt/dist/app/entry.js",
    "isEntry": true,
    "dynamicImports": [
      "layouts/default.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "css": [
      "entry.BNLsRXEw.css"
    ],
    "_globalCSS": true
  },
  "entry.BNLsRXEw.css": {
    "file": "entry.BNLsRXEw.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.DwE7vIOb.js",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "_Input.CD2kiVdc.js"
    ],
    "css": [
      "index.1dWLzkEK.css"
    ]
  },
  "index.1dWLzkEK.css": {
    "file": "index.1dWLzkEK.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/login.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "login.DdQRe2gh.js",
    "src": "pages/login.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Input.CD2kiVdc.js"
    ],
    "css": [
      "login.BUEnMcmd.css"
    ],
    "assets": [
      "wx.B1fgWuP-.png"
    ]
  },
  "login.BUEnMcmd.css": {
    "file": "login.BUEnMcmd.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "wx.B1fgWuP-.png": {
    "file": "wx.B1fgWuP-.png",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
